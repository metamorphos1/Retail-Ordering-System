import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

class Product {
    private int id;
    private String name;
    private double price;

    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Price: $" + price;
    }
}

class Order {
    private Map<Product, Integer> products = new HashMap<>();

    public void addProduct(Product product, int quantity) {
        products.put(product, products.getOrDefault(product, 0) + quantity);
    }

    public String getOrderDetails() {
        StringBuilder details = new StringBuilder();
        double total = 0;
        for (Map.Entry<Product, Integer> entry : products.entrySet()) {
            Product product = entry.getKey();
            int quantity = entry.getValue();
            double productTotal = product.getPrice() * quantity;
            total += productTotal;
            details.append(product.getName()).append(" x ").append(quantity).append(" = $").append(productTotal).append("\n");
        }
        details.append("Total Payment: $").append(total);
        return details.toString();
    }

    public void clearOrder() {
        products.clear();
    }
}

class Admin {
    private List<Product> inventory = new ArrayList<>();

    public void addProduct(Product product) {
        inventory.add(product);
    }

    public void modifyProductPrice(int id, double newPrice) {
        for (Product product : inventory) {
            if (product.getId() == id) {
                product.setPrice(newPrice);
                return;
            }
        }
    }

    public void removeProduct(int id) {
        inventory.removeIf(product -> product.getId() == id);
    }

    public List<Product> getInventory() {
        return inventory;
    }
}

public class RetailOrderingSystemGUI {
    private static Admin admin;
    private static Order customerOrder;
    private static JFrame frame;
    private static JPanel panel;

    public static void main(String[] args) {
        admin = new Admin();
        customerOrder = new Order();
        frame = new JFrame("Retail Ordering System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        showLoginScreen();
        frame.setVisible(true);
    }

    private static void showLoginScreen() {
        panel = new JPanel(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton exitButton = new JButton("Exit");

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (username.equals("adminuz") && password.equals("1234")) {
                showAdminMenu();
            } else if (username.equals("marcus") && password.equals("1234")) {
                showCustomerMenu();
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid credentials. Try again.");
            }
        });

        exitButton.addActionListener(e -> System.exit(0));

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(exitButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showAdminMenu() {
        panel = new JPanel(new GridLayout(5, 1));


        JButton addProductButton = new JButton("Add Product");
        JButton modifyPriceButton = new JButton("Modify Product Price");
        JButton removeProductButton = new JButton("Remove Product");
        JButton viewProductsButton = new JButton("View Products");
        JButton backButton = new JButton("Logout");

        addProductButton.addActionListener(e -> showAddProductScreen());
        modifyPriceButton.addActionListener(e -> showModifyPriceScreen());
        removeProductButton.addActionListener(e -> showRemoveProductScreen());
        viewProductsButton.addActionListener(e -> showProductList());
        backButton.addActionListener(e -> showLoginScreen());

        panel.add(addProductButton);
        panel.add(modifyPriceButton);
        panel.add(removeProductButton);
        panel.add(viewProductsButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showAddProductScreen() {
        panel = new JPanel(new GridLayout(4, 2));

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField priceField = new JTextField();

        JButton addButton = new JButton("Add Product");
        JButton backButton = new JButton("Back");

        addButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                double price = Double.parseDouble(priceField.getText());
                admin.addProduct(new Product(id, name, price));
                JOptionPane.showMessageDialog(frame, "Product added successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid data.");
            }
        });

        backButton.addActionListener(e -> showAdminMenu());

        panel.add(new JLabel("Product ID:"));
        panel.add(idField);
        panel.add(new JLabel("Product Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Product Price:"));
        panel.add(priceField);
        panel.add(addButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showModifyPriceScreen() {
        panel = new JPanel(new GridLayout(3, 2));

        JTextField idField = new JTextField();
        JTextField priceField = new JTextField();

        JButton modifyButton = new JButton("Modify Price");
        JButton backButton = new JButton("Back");

        modifyButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                double newPrice = Double.parseDouble(priceField.getText());
                admin.modifyProductPrice(id, newPrice);
                JOptionPane.showMessageDialog(frame, "Price updated successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid data.");
            }
        });

        backButton.addActionListener(e -> showAdminMenu());

        panel.add(new JLabel("Product ID:"));
        panel.add(idField);
        panel.add(new JLabel("New Price:"));
        panel.add(priceField);
        panel.add(modifyButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showRemoveProductScreen() {
        panel = new JPanel(new GridLayout(2, 2));

        JTextField idField = new JTextField();

        JButton removeButton = new JButton("Remove Product");
        JButton backButton = new JButton("Back");


        removeButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                admin.removeProduct(id);
                JOptionPane.showMessageDialog(frame, "Product removed successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid ID.");
            }
        });

        backButton.addActionListener(e -> showAdminMenu());

        panel.add(new JLabel("Product ID:"));
        panel.add(idField);
        panel.add(removeButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showProductList() {
        panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JTextArea productList = new JTextArea();
        productList.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(productList);

        for (Product product : admin.getInventory()) {
            productList.append(product.toString() + "\n");
        }

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> showAdminMenu());

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showCustomerMenu() {
        panel = new JPanel(new GridLayout(4, 1));

        JButton viewProductsButton = new JButton("View Products");
        JButton orderProductButton = new JButton("Order Product");
        JButton viewTotalButton = new JButton("View Total Payment");
        JButton backButton = new JButton("Logout");

        viewProductsButton.addActionListener(e -> showProductList());
        orderProductButton.addActionListener(e -> showOrderProductScreen());
        viewTotalButton.addActionListener(e -> showTotalPayment());
        backButton.addActionListener(e -> showLoginScreen());

        panel.add(viewProductsButton);
        panel.add(orderProductButton);
        panel.add(viewTotalButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showOrderProductScreen() {
        panel = new JPanel(new GridLayout(3, 2));

        JTextField idField = new JTextField();
        JTextField quantityField = new JTextField();

        JButton orderButton = new JButton("Order Product");
        JButton backButton = new JButton("Back");

        orderButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                for (Product product : admin.getInventory()) {
                    if (product.getId() == id) {
                        customerOrder.addProduct(product, quantity);
                        JOptionPane.showMessageDialog(frame, "Product added to order.");
                        return;
                    }
                }
                JOptionPane.showMessageDialog(frame, "Product not found.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid data.");
            }
        });

        backButton.addActionListener(e -> showCustomerMenu());

        panel.add(new JLabel("Product ID:"));
        panel.add(idField);
        panel.add(new JLabel("Quantity:"));
        panel.add(quantityField);
        panel.add(orderButton);
        panel.add(backButton);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static void showTotalPayment() {
        JOptionPane.showMessageDialog(frame, customerOrder.getOrderDetails());
    }
}
